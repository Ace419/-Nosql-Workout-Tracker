// Exporting an object containing all of our models

module.exports = {
    workout: require("./workout")    
  };